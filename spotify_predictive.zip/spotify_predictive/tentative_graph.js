const CHART = document.getElementById("graphTwo");

    let graphTwo = new Chart(CHART, {
        type: 'bar',
        data: {
            labels: ['Mamta', 'Zoe','Kelly'],
            datasets: [
                {
                    label: "Energy",
                    fill: true,
                    lineTension: 0.1,
                    backgroundColor: "rgba(51,51,255,0.1)",
                    borderColor:"rgba(0,51,255,6)",
                    borderCapStyle: 'round',
                    borderDash:[],
                    borderDashOffset:0.0,
                    borderJoinStyle: 'mitter',
                    pointBoderColor: "rgba(155, 99, 132, 2)",
                    pointerBackgroundColor: "#fff",
                    pointerBorderWidth: 4,
                    pointerHoverRadius: 5,
                    pointHoverBackgroundColor: "rgba(155, 99, 132, 3)",
                    pointHoverBorderColor: "rgba(220, 220, 220, 3)",
                    pointHoverBorderWidth:2,
                    pointRadius: 8,
                    pointHitRadius:10,
                    // data should be cost of living
                    data: ["0.557756","0.667","0.665350"],
                    yAxisID: 'y-axis-1',                },
                {
                    label: "Loudness",
                    fill: true,
                    lineTension: 1, 
                    backgroundColor: "rgba(255,0,0,0.2)",
                    borderColor:"rgba(255, 179, 64, 6)",
                    borderCapStyle: 'round',
                    borderDash:[],
                    borderDashOffset:0.0,
                    borderJoinStyle: 'mitter',
                    pointBoderColor: "rgba(255, 159, 64, 2)",
                    pointerBackgroundColor: "#fff",
                    pointerBorderWidth: 4,
                    pointerHoverRadius: 5,
                    pointHoverBackgroundColor: "rgba(255, 156, 64, 0.5)",
                    pointHoverBorderColor: "rgba(120, 120, 160, 1)",
                    pointHoverBorderWidth:2,
                    pointRadius: 8,
                    pointHitRadius:10,
                    // data should be income
                    data: ["-9.00656","-6.00965","-6.83917"],
                    yAxisID: 'y-axis-2'
                },
                {
                    label: "Tempo",
                    fill: true,
                    lineTension: 0,
                    backgroundColor: "rgba(155, 99, 132, 3)",
                    borderColor:"rgba(51,255,102,7)",
                    borderCapStyle: 'round',
                    borderDash:[],
                    borderDashOffset:0.0,
                    borderJoinStyle: 'mitter',
                    pointBoderColor: "rgba(155, 99, 132, 3)",
                    pointerBackgroundColor: "#fff",
                    pointerBorderWidth: 4,
                    pointerHoverRadius: 5,
                    pointHoverBackgroundColor: "rgba(155, 99, 132, 3)",
                    pointHoverBorderColor: "rgba(220, 220, 220, 3)",
                    pointHoverBorderWidth:2,
                    pointRadius: 8,
                    pointHitRadius:10,
                    // data should be from machine learning
                    data: ["119","120","117.85288"],
                    // yAxisID: 'y-axis-1', 
                               },
                               {
                                label: "Valence",
                                fill: true,
                                lineTension: 0,
                                backgroundColor: "rgba(244, 66, 226,3)",
                                borderColor:"rgba(51,255,102,7)",
                                borderCapStyle: 'round',
                                borderDash:[],
                                borderDashOffset:0.0,
                                borderJoinStyle: 'mitter',
                                pointBoderColor: "rgba(150, 79, 132, 3)",
                                pointerBackgroundColor: "#fff",
                                pointerBorderWidth: 4,
                                pointerHoverRadius: 5,
                                pointHoverBackgroundColor: "rgba(244, 66, 226,3)",
                                pointHoverBorderColor: "rgba(220, 220, 220, 3)",
                                pointHoverBorderWidth:2,
                                pointRadius: 8,
                                pointHitRadius:10,
                                // data should be from machine learning
                                data: ["0.497036","-0.51339","0.453720"],
                                // yAxisID: 'y-axis-1', 
                                           }
            ]},
            options: {
                responsive: true,
                title: {
					display: true,
					text: 'Music Machine Learing'
				},
				tooltips: {
					mode: 'index'
				},
                scales: {
                    yAxes:[{
                        display: true,
						scaleLabel: {
							display: true,
							labelString: 'Mean'
						},
                        type:'linear',
                        ticks: {
                            beginAtZero:true
                        },
                        position: 'left',
						id: 'y-axis-1'
                    },
                    {
                        display: false,
						scaleLabel: {
							display: true,
							labelString: 'Mean'
						},
                        type:'linear',
                        ticks: {
                            beginAtZero:true
                        },
                        position: 'right',
                        id: 'y-axis-2',
                        gridLines: {
                            drawOnChartArea: false, // only want the grid lines for one axis to show up
                        }
                    }]            
                     }
                }
    
            }
    );